#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Pepper Clinical Infinity V6 — Enhanced Edition
# Install Script
# ═══════════════════════════════════════════════════════════════
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  Pepper Clinical Infinity V6 — Enhanced Edition         ║"
echo "║  PECS×50 | ISAA/ISQA | Treatment Plan | No-Repeat      ║"
echo "╚══════════════════════════════════════════════════════════╝"

# System packages
echo "[1/6] Installing system packages..."
sudo apt-get update -q
sudo apt-get install -y \
    python3.9 python3.9-dev python3-pip \
    libgl1-mesa-glx libglib2.0-0 libsm6 libxrender1 \
    libportaudio2 portaudio19-dev ffmpeg espeak \
    alsa-utils libxcb-xinerama0 sqlite3 2>/dev/null || true
echo "✅ System packages"

# Conda
echo "[2/6] Setting up Conda..."
if ! command -v conda &>/dev/null; then
    wget -q "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" \
        -O /tmp/miniconda.sh
    bash /tmp/miniconda.sh -b -p $HOME/miniconda3
    export PATH="$HOME/miniconda3/bin:$PATH"
    echo 'export PATH="$HOME/miniconda3/bin:$PATH"' >> ~/.bashrc
fi
source $(conda info --base)/etc/profile.d/conda.sh
conda create -n pepper_stable python=3.9 -y 2>/dev/null || true
conda activate pepper_stable
echo "✅ Conda ready"

# Python packages
echo "[3/6] Installing Python packages..."
pip install --upgrade pip -q
pip install PyQt6 PyQt6-Qt6 PyQt6-sip -q
pip install opencv-python-headless==4.8.1.78 -q
pip install mediapipe==0.10.14 -q
pip install faster-whisper -q
pip install SpeechRecognition pyaudio -q
pip install pyttsx3 -q
pip install flask flask-cors -q
pip install google-generativeai -q
pip install pybullet qibullet -q
pip install Pillow reportlab -q
pip install numpy scipy -q
echo "✅ Python packages"

# Project structure
echo "[4/6] Setting up project..."
mkdir -p ~/pepper_duo/src ~/pepper_duo/auth ~/pepper_duo/logs
cp "$(dirname "$0")/src/pepper_v6_enhanced.py" ~/pepper_duo/src/
echo "✅ Project structure"

# Test imports
echo "[5/6] Testing imports..."
python3 -c "
tests=[('PyQt6.QtWidgets','PyQt6'),('cv2','OpenCV'),
       ('mediapipe','MediaPipe'),('faster_whisper','Whisper'),
       ('speech_recognition','ASR'),('pyttsx3','TTS'),
       ('flask','Flask'),('pybullet','PyBullet'),
       ('qibullet','qiBullet'),('PIL','Pillow'),
       ('reportlab','ReportLab'),('sqlite3','SQLite')]
ok,fail=[],[]
for mod,name in tests:
    try: __import__(mod); print(f'  ✅ {name}'); ok.append(name)
    except ImportError as e: print(f'  ❌ {name}: {e}'); fail.append(name)
print(f'\nPassed: {len(ok)}/{len(tests)}')
if not fail: print('✅ All ready!')
else: print(f'Failed: {fail}')
"

# Desktop shortcut
echo "[6/6] Creating launcher..."
cat > ~/Desktop/PepperV6_Enhanced.sh << 'LAUNCHER'
#!/bin/bash
cd ~/pepper_duo/src
source ~/miniconda3/bin/activate pepper_stable 2>/dev/null || \
    source $(conda info --base)/etc/profile.d/conda.sh && conda activate pepper_stable
export QT_QPA_PLATFORM=xcb
export TF_CPP_MIN_LOG_LEVEL=3
export PYTHONWARNINGS=ignore
python3 pepper_v6_enhanced.py
LAUNCHER
chmod +x ~/Desktop/PepperV6_Enhanced.sh 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✅ Installation complete!                                ║"
echo "║                                                          ║"
echo "║  Run:                                                    ║"
echo "║    cd ~/pepper_duo/src                                   ║"
echo "║    conda activate pepper_stable                          ║"
echo "║    python3 pepper_v6_enhanced.py                         ║"
echo "║                                                          ║"
echo "║  Dashboard: http://localhost:5007                        ║"
echo "╚══════════════════════════════════════════════════════════╝"
