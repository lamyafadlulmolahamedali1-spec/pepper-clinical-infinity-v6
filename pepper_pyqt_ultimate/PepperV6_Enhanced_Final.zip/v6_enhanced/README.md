# Pepper Clinical Infinity V6 — Enhanced Edition

## What's New vs Original V6

| Feature | Original | Enhanced |
|---------|----------|----------|
| PECS items | 10 | **50** (all 5 categories) |
| AI Advice | 404 error | **Fixed** — works perfectly |
| PDF Report | Basic stats | **Full treatment plan** + SMART goals + weekly schedule + all sessions |
| Screening | ISCA only | **ISCA + ISAA + ISQA** (validated ASD tools) |
| Child profiles | Session only | **Permanent SQLite** — survives restarts |
| Session storage | CSV only | **SQLite per child** — all sessions on dashboard |
| Task repetition | Possible | **Zero repeats** per child — unless parent presses Refresh |

## Quick Start

```bash
chmod +x INSTALL.sh && ./INSTALL.sh
cd ~/pepper_duo/src
conda activate pepper_stable
python3 pepper_v6_enhanced.py
```

## Dashboard: http://localhost:5007

### Tabs:
1. **📊 Overview** — Live stats, skill bars, emotion detection
2. **🧠 Diagnosis** — Auto clinical assessment + treatment recommendations
3. **👶 Children** — Register children permanently (SQLite)
4. **📅 Sessions** — All sessions per child with full history
5. **🧪 Screening** — ISCA (10 items) + ISAA (16 items) + ISQA (10 items)
6. **📋 Log** — Session events + PECS usage log
7. **🗣️ PECS** — All 50 communication cards
8. **💬 Chat** — Session conversation history
9. **🤖 AI Advice** — Gemini clinical advisor (FIXED — no 404!)
10. **⚡ Actions** — Remote control + 🔄 Refresh child tasks

## 🔄 Refresh Button
On the **⚡ Actions** tab, press **🔄 Refresh** to reset task history
for the current child — they will see all tasks again.

## PDF Report Includes:
1. Session summary table
2. Skill domain analysis with status
3. **Full individualised treatment plan** (per domain)
4. **Recommended weekly schedule** (Mon–Sun)
5. **SMART goals** (next 4 weeks)
6. **All sessions history** from SQLite
7. Session event log

## Screening Tools:
- **ISCA** — 10 items, cutoff >6 monitoring, >12 referral
- **ISAA** — 16 items, Indian Scale for Assessment of Autism
- **ISQA** — 10 items, Integrated Screening Questionnaire
