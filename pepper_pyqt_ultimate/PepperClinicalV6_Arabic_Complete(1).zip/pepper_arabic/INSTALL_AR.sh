#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# تثبيت بيبر كلينيكال إنفينيتي V6 — النسخة العربية
# شغّل هذا الملف على Ubuntu 22.04:
#   chmod +x INSTALL_AR.sh && ./INSTALL_AR.sh
# ═══════════════════════════════════════════════════════════════
set -e
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  بيبر كلينيكال إنفينيتي V6 — النسخة العربية الكاملة     ║"
echo "║  للمراكز العربية لعلاج اضطراب طيف التوحد                ║"
echo "╚═══════════════════════════════════════════════════════════╝"

# 1) حزم النظام
echo "[1/7] تثبيت حزم النظام..."
sudo apt-get update -q
sudo apt-get install -y \
    python3.9 python3.9-dev python3.9-venv python3-pip \
    libgl1-mesa-glx libglib2.0-0 libsm6 libxrender1 libxext6 \
    libportaudio2 portaudio19-dev ffmpeg \
    espeak espeak-data libespeak-dev \
    alsa-utils pulseaudio \
    libxcb-xinerama0 libxcb1 libx11-6 \
    git wget curl unzip 2>/dev/null || true
echo "✅ حزم النظام جاهزة"

# 2) Miniconda
echo "[2/7] إعداد Conda..."
if ! command -v conda &>/dev/null; then
    wget -q https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh \
        -O /tmp/miniconda.sh
    bash /tmp/miniconda.sh -b -p $HOME/miniconda3
    export PATH="$HOME/miniconda3/bin:$PATH"
    echo 'export PATH="$HOME/miniconda3/bin:$PATH"' >> ~/.bashrc
    conda init bash
fi
echo "✅ Conda جاهز"

# 3) بيئة pepper_stable
echo "[3/7] إنشاء بيئة pepper_stable (Python 3.9)..."
conda create -n pepper_stable python=3.9 -y 2>/dev/null || true
source $(conda info --base)/etc/profile.d/conda.sh
conda activate pepper_stable
echo "✅ البيئة جاهزة"

# 4) تثبيت المكتبات
echo "[4/7] تثبيت المكتبات..."
pip install --upgrade pip -q
pip install PyQt6 PyQt6-Qt6 PyQt6-sip -q
pip install opencv-python-headless==4.8.1.78 -q
pip install mediapipe==0.10.14 -q
pip install faster-whisper -q
pip install SpeechRecognition pyaudio -q
pip install pyttsx3 -q
pip install flask flask-cors -q
pip install google-generativeai -q
pip install pybullet -q
pip install qibullet -q
pip install Pillow -q
pip install reportlab -q
pip install numpy scipy -q
pip install requests python-dotenv -q
echo "✅ جميع المكتبات مثبتة"

# 5) بنية المشروع
echo "[5/7] إنشاء بنية المشروع..."
mkdir -p ~/pepper_duo/src ~/pepper_duo/logs ~/pepper_duo/reports
cp "$(dirname "$0")/src/pepper_v6_arabic.py" ~/pepper_duo/src/
echo "✅ ملفات المشروع منسوخة"

# 6) اختبار الاستيراد
echo "[6/7] اختبار الاستيراد..."
python3 -c "
tests=[('PyQt6.QtWidgets','PyQt6'),('cv2','OpenCV'),
       ('mediapipe','MediaPipe'),('faster_whisper','Whisper'),
       ('speech_recognition','ASR'),('pyttsx3','TTS'),
       ('flask','Flask'),('pybullet','PyBullet'),
       ('qibullet','qiBullet'),('PIL','Pillow'),('reportlab','ReportLab')]
ok=[]; fail=[]
for mod,name in tests:
    try: __import__(mod); print(f'  ✅ {name}'); ok.append(name)
    except ImportError as e: print(f'  ❌ {name}: {e}'); fail.append(name)
print(f'\nنجح: {len(ok)}/{len(tests)}')
if fail: print(f'فشل: {fail}')
else: print('✅ جميع المكتبات تعمل!')
"

# 7) اختصار سطح المكتب
echo "[7/7] إنشاء اختصار سطح المكتب..."
cat > ~/Desktop/بيبر_عربي.sh << 'LAUNCHER'
#!/bin/bash
cd ~/pepper_duo/src
source ~/miniconda3/bin/activate pepper_stable 2>/dev/null || \
    source $(conda info --base)/etc/profile.d/conda.sh && conda activate pepper_stable
export QT_QPA_PLATFORM=xcb
export TF_CPP_MIN_LOG_LEVEL=3
export PYTHONWARNINGS=ignore
python3 pepper_v6_arabic.py
LAUNCHER
chmod +x ~/Desktop/بيبر_عربي.sh 2>/dev/null || true

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  ✅ التثبيت مكتمل!                                        ║"
echo "║                                                           ║"
echo "║  للتشغيل:                                                 ║"
echo "║    cd ~/pepper_duo/src                                    ║"
echo "║    conda activate pepper_stable                           ║"
echo "║    python3 pepper_v6_arabic.py                            ║"
echo "║                                                           ║"
echo "║  لوحة الوالدين: http://localhost:5007                     ║"
echo "╚═══════════════════════════════════════════════════════════╝"
