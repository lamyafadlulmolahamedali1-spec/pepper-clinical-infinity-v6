# 🤖 بيبر كلينيكال إنفينيتي V6 — النسخة العربية النهائية

## صوت Piper ar_JO-kareem + مصادقة الوالدين الكاملة

---

## 📁 الملفات
```
pepper_arabic_v2/
├── INSTALL_FINAL.sh              ← شغّل هذا أولاً
├── download_voice.sh             ← لتحميل نموذج الصوت
├── run.sh                        ← للتشغيل السريع
├── src/
│   └── pepper_v6_arabic_final.py ← الكود الكامل (2,440 سطر)
└── README.md
```

---

## 🚀 تشغيل سريع

```bash
# 1 — تثبيت كل شيء
chmod +x INSTALL_FINAL.sh && ./INSTALL_FINAL.sh

# 2 — تشغيل
cd ~/pepper_duo/src
conda activate pepper_stable
python3 pepper_v6_arabic_final.py
```

---

## 🔊 الصوت العربي — Piper

```bash
# اختبار الصوت يدوياً
echo "أهلاً يا أحمد! أنا صديقك الجديد، هل تريد أن نلعب معاً؟" | \
  piper --model ~/pepper_duo/models/ar_JO-kareem-medium.onnx \
  --length_scale 0.85 --output_file kid_voice.wav && aplay kid_voice.wav
```

---

## 🔐 نظام المصادقة

```
http://localhost:5007

1. صفحة التسجيل  ← أنشئ حساب جديد (اسم + بريد + كلمة مرور)
2. صفحة الدخول   ← ادخل بالبريد وكلمة المرور
3. لوحة الوالدين ← 9 تبويبات كاملة بالعربية
4. زر الخروج     ← في أعلى اللوحة
```

---

## ✅ المميزات الكاملة

| الميزة | التفاصيل |
|--------|---------|
| 🔊 Piper TTS | صوت ar_JO-kareem-medium — طبيعي للأطفال |
| 🔐 مصادقة كاملة | تسجيل + دخول + كوكيز + SQLite |
| 🤖 بيبر PyBullet | غرفة علاج عربية 5 مناطق |
| 😊 كشف المشاعر | 7 فئات عربية + EMA |
| ✋ 10 أصابع | تصحيح الجانبية الكامل |
| 👄 حركة الشفاه | EMA8 للتحقق من النطق |
| 🎤 ASR | Whisper عربي + Google عربي |
| 🎯 4,650+ مهمة | 10 مجالات عربية |
| 🗣️ 50 PECS | كل التواصل اليومي عربي |
| 📊 لوحة وإلدين | 9 تبويبات محمية بتسجيل الدخول |
| 🤖 Gemini AI | مشورة سريرية عربية |
| 📄 تقرير PDF | سريري عربي |
