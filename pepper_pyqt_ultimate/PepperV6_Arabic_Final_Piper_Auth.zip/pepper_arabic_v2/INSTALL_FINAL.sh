#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# تثبيت بيبر كلينيكال V6 — النسخة العربية النهائية
# صوت Piper + مصادقة الوالدين
# ═══════════════════════════════════════════════════════════════
set -e
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  بيبر كلينيكال V6 — النسخة العربية النهائية             ║"
echo "║  صوت Piper ar_JO-kareem + مصادقة الوالدين              ║"
echo "╚══════════════════════════════════════════════════════════╝"

# 1) حزم النظام
echo "[1/8] تثبيت حزم النظام..."
sudo apt-get update -q
sudo apt-get install -y \
    python3.9 python3.9-dev python3-pip \
    libgl1-mesa-glx libglib2.0-0 libsm6 libxrender1 libxext6 \
    libportaudio2 portaudio19-dev ffmpeg \
    espeak espeak-data libespeak-dev \
    alsa-utils pulseaudio \
    libxcb-xinerama0 libxcb1 \
    wget curl unzip sqlite3 2>/dev/null || true
echo "✅ حزم النظام"

# 2) Piper TTS
echo "[2/8] تثبيت Piper TTS..."
pip install piper-tts 2>/dev/null || {
    # تثبيت يدوي
    wget -q "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_x86_64.tar.gz" \
        -O /tmp/piper.tar.gz
    tar -xzf /tmp/piper.tar.gz -C /usr/local/bin/ 2>/dev/null || true
}
echo "✅ Piper TTS"

# 3) Miniconda
echo "[3/8] إعداد Conda..."
if ! command -v conda &>/dev/null; then
    wget -q "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" \
        -O /tmp/miniconda.sh
    bash /tmp/miniconda.sh -b -p $HOME/miniconda3
    export PATH="$HOME/miniconda3/bin:$PATH"
    echo 'export PATH="$HOME/miniconda3/bin:$PATH"' >> ~/.bashrc
fi
echo "✅ Conda"

# 4) بيئة Python
echo "[4/8] إنشاء بيئة pepper_stable..."
source $(conda info --base)/etc/profile.d/conda.sh
conda create -n pepper_stable python=3.9 -y 2>/dev/null || true
conda activate pepper_stable
echo "✅ البيئة جاهزة"

# 5) المكتبات
echo "[5/8] تثبيت المكتبات..."
pip install --upgrade pip -q
pip install PyQt6 PyQt6-Qt6 PyQt6-sip -q
pip install opencv-python-headless==4.8.1.78 -q
pip install mediapipe==0.10.14 -q
pip install faster-whisper -q
pip install SpeechRecognition pyaudio -q
pip install pyttsx3 -q
pip install flask flask-cors -q
pip install google-generativeai -q
pip install pybullet qibullet -q
pip install Pillow reportlab -q
pip install numpy scipy bcrypt -q
pip install requests python-dotenv -q
echo "✅ المكتبات"

# 6) بنية المشروع
echo "[6/8] إنشاء بنية المشروع..."
mkdir -p ~/pepper_duo/src ~/pepper_duo/models ~/pepper_duo/auth ~/pepper_duo/logs
cp "$(dirname "$0")/src/pepper_v6_arabic_final.py" ~/pepper_duo/src/
echo "✅ الملفات منسوخة"

# 7) تحميل نموذج الصوت
echo "[7/8] تحميل نموذج الصوت العربي..."
bash "$(dirname "$0")/download_voice.sh" || echo "⚠️  حمّل النموذج يدوياً: bash download_voice.sh"

# 8) اختبار
echo "[8/8] اختبار الاستيراد..."
python3 -c "
tests=[('PyQt6.QtWidgets','PyQt6'),('cv2','OpenCV'),
       ('mediapipe','MediaPipe'),('faster_whisper','Whisper'),
       ('speech_recognition','ASR'),('pyttsx3','TTS'),
       ('flask','Flask'),('pybullet','PyBullet'),
       ('qibullet','qiBullet'),('PIL','Pillow'),
       ('reportlab','ReportLab'),('bcrypt','bcrypt'),('sqlite3','SQLite')]
ok,fail=[],[]
for mod,name in tests:
    try: __import__(mod); print(f'  ✅ {name}'); ok.append(name)
    except ImportError as e: print(f'  ❌ {name}: {e}'); fail.append(name)
print(f'\nنجح: {len(ok)}/{len(tests)}')
if fail: print(f'فشل: {fail}')
else: print('✅ جاهز للتشغيل!')
"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✅ التثبيت مكتمل!                                       ║"
echo "║                                                          ║"
echo "║  للتشغيل:                                                ║"
echo "║    cd ~/pepper_duo/src                                   ║"
echo "║    conda activate pepper_stable                          ║"
echo "║    python3 pepper_v6_arabic_final.py                     ║"
echo "║                                                          ║"
echo "║  لوحة الوالدين: http://localhost:5007                    ║"
echo "║  سجّل أولاً ← ثم ادخل للوحة الوالدين                    ║"
echo "╚══════════════════════════════════════════════════════════╝"
