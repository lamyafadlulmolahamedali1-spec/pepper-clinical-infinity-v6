#!/bin/bash
cd ~/pepper_duo/src
source ~/miniconda3/bin/activate pepper_stable 2>/dev/null || \
    source $(conda info --base)/etc/profile.d/conda.sh && conda activate pepper_stable
export QT_QPA_PLATFORM=xcb
export TF_CPP_MIN_LOG_LEVEL=3
export PYTHONWARNINGS=ignore
echo "🤖 تشغيل بيبر كلينيكال V6 — صوت Piper العربي..."
python3 pepper_v6_arabic_final.py
