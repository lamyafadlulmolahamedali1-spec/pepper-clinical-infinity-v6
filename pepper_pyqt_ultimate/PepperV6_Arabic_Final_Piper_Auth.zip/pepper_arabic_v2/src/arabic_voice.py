#!/usr/bin/env python3
"""
محرك الصوت العربي — Piper TTS + pyttsx3 fallback
يستخدم ar_JO-kareem-medium.onnx للصوت العربي الطبيعي للأطفال
"""
import os, subprocess, tempfile, threading, time, random, logging
import speech_recognition as sr
import numpy as np

log = logging.getLogger("صوت_عربي")

class ArabicVoiceEngine:
    """
    محرك الصوت العربي الكامل:
    - المستوى الأول: Piper TTS (ar_JO-kareem-medium.onnx) — صوت عربي طبيعي
    - المستوى الثاني: pyttsx3 — احتياطي إذا لم يتوفر Piper
    """
    def __init__(self, model_path="./models/ar_JO-kareem-medium.onnx",
                 length_scale=0.85, speed=1.0):
        self.model_path = model_path
        self.length_scale = length_scale
        self._lock = threading.Lock()
        self._speaking = False
        self._interrupt = False
        self._piper_ok = False
        self._tts = None
        self._check_piper()
        if not self._piper_ok:
            self._init_fallback()

    def _check_piper(self):
        """التحقق من توفر Piper والنموذج العربي"""
        try:
            result = subprocess.run(
                ["piper", "--version"],
                capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                if os.path.exists(self.model_path):
                    self._piper_ok = True
                    log.info(f"✅ Piper TTS جاهز — النموذج: {self.model_path}")
                else:
                    log.warning(f"⚠️  النموذج غير موجود: {self.model_path}")
                    log.warning("    حمّل النموذج: bash download_voice.sh")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            log.warning("⚠️  Piper غير مثبت — سيتم استخدام pyttsx3")

    def _init_fallback(self):
        """pyttsx3 كبديل احتياطي"""
        try:
            import pyttsx3
            self._tts = pyttsx3.init()
            self._tts.setProperty("rate", 105)
            self._tts.setProperty("volume", 1.0)
            voices = self._tts.getProperty("voices")
            for v in voices:
                vn = v.name.lower()
                if any(x in vn for x in ["arabic","arab","ar-","hoda","naayf"]):
                    self._tts.setProperty("voice", v.id)
                    log.info(f"✅ pyttsx3 صوت عربي: {v.name}")
                    break
            log.info("✅ pyttsx3 جاهز (احتياطي)")
        except Exception as e:
            log.warning(f"pyttsx3: {e}")

    def say(self, text: str, wait=True, interrupt_ok=True):
        """
        نطق النص بالعربية
        يستخدم Piper أولاً ثم pyttsx3
        """
        if not text or not text.strip(): return
        self._interrupt = False
        self._speaking = True
        clean = text.strip()

        def _speak():
            try:
                if self._piper_ok:
                    self._piper_say(clean)
                elif self._tts:
                    self._tts_say(clean)
                else:
                    log.info(f"[صوت]: {clean}")
            finally:
                self._speaking = False

        if wait:
            _speak()
        else:
            threading.Thread(target=_speak, daemon=True).start()

    def _piper_say(self, text: str):
        """نطق باستخدام Piper TTS"""
        with self._lock:
            try:
                # إنشاء ملف مؤقت
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                    wav_path = tmp.name

                # توليد الصوت بـ Piper
                cmd = [
                    "piper",
                    "--model", self.model_path,
                    "--length_scale", str(self.length_scale),
                    "--output_file", wav_path
                ]
                proc = subprocess.run(
                    cmd,
                    input=text,
                    capture_output=True,
                    text=True,
                    timeout=15)

                if proc.returncode == 0 and os.path.exists(wav_path):
                    # تشغيل الصوت بـ aplay
                    if not self._interrupt:
                        aplay = subprocess.Popen(
                            ["aplay", wav_path],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
                        # انتظر مع إمكانية المقاطعة
                        while aplay.poll() is None:
                            if self._interrupt:
                                aplay.terminate()
                                break
                            time.sleep(0.05)
                else:
                    log.warning(f"Piper خطأ: {proc.stderr[:100]}")
                    # fallback
                    if self._tts: self._tts_say(text)
            except subprocess.TimeoutExpired:
                log.warning("Piper انتهى الوقت")
                if self._tts: self._tts_say(text)
            except Exception as e:
                log.warning(f"Piper: {e}")
                if self._tts: self._tts_say(text)
            finally:
                try: os.unlink(wav_path)
                except: pass

    def _tts_say(self, text: str):
        """نطق باستخدام pyttsx3"""
        if not self._tts: return
        try:
            self._tts.say(text)
            self._tts.runAndWait()
        except: pass

    def say_pecs(self, text: str):
        """نطق PECS مع مقاطعة الصوت الحالي"""
        self.interrupt()
        time.sleep(0.15)
        threading.Thread(
            target=self.say, args=(text, True), daemon=True).start()

    def interrupt(self):
        """مقاطعة الصوت الحالي"""
        self._interrupt = True
        self._speaking = False
        try: os.system("pkill -f aplay 2>/dev/null")
        except: pass
        if self._tts:
            try: self._tts.stop()
            except: pass

    def cleanup(self):
        self.interrupt()
        try: os.system("pkill -f aplay 2>/dev/null")
        except: pass

    @property
    def is_speaking(self): return self._speaking

