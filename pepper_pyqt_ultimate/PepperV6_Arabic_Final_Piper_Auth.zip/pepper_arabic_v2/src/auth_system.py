#!/usr/bin/env python3
"""
نظام المصادقة — تسجيل وتسجيل دخول الوالدين
bcrypt للتشفير + SQLite للبيانات
"""
import os, json, hashlib, secrets, time, sqlite3, re
from datetime import datetime, timedelta
from functools import wraps
from flask import request, session, redirect, jsonify

DB_PATH = os.path.expanduser("~/pepper_duo/auth/parents.db")

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS parents (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            email       TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,
            name        TEXT NOT NULL,
            center_name TEXT DEFAULT '',
            phone       TEXT DEFAULT '',
            created_at  TEXT NOT NULL,
            last_login  TEXT,
            is_active   INTEGER DEFAULT 1
        )""")
    c.execute("""
        CREATE TABLE IF NOT EXISTS children (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id   INTEGER NOT NULL,
            name        TEXT NOT NULL,
            age         INTEGER DEFAULT 6,
            asd_level   INTEGER DEFAULT 2,
            notes       TEXT DEFAULT '',
            created_at  TEXT NOT NULL,
            FOREIGN KEY (parent_id) REFERENCES parents(id)
        )""")
    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token       TEXT PRIMARY KEY,
            parent_id   INTEGER NOT NULL,
            created_at  TEXT NOT NULL,
            expires_at  TEXT NOT NULL,
            FOREIGN KEY (parent_id) REFERENCES parents(id)
        )""")
    conn.commit(); conn.close()

def _hash_pw(password: str) -> str:
    """تشفير كلمة المرور بـ bcrypt أو SHA-256"""
    try:
        import bcrypt
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    except ImportError:
        salt = secrets.token_hex(16)
        h = hashlib.sha256((password + salt).encode()).hexdigest()
        return f"sha256:{salt}:{h}"

def _verify_pw(password: str, hashed: str) -> bool:
    try:
        if hashed.startswith("sha256:"):
            _, salt, h = hashed.split(":")
            return hashlib.sha256((password + salt).encode()).hexdigest() == h
        import bcrypt
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except: return False

def register_parent(email, password, name, center_name="", phone=""):
    """تسجيل ولي أمر جديد"""
    email = email.strip().lower()
    if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
        return False, "البريد الإلكتروني غير صحيح"
    if len(password) < 8:
        return False, "كلمة المرور يجب أن تكون 8 أحرف على الأقل"
    if not name.strip():
        return False, "الاسم مطلوب"
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id FROM parents WHERE email=?", (email,))
        if c.fetchone():
            conn.close()
            return False, "البريد الإلكتروني مسجل مسبقاً"
        hashed = _hash_pw(password)
        c.execute("""INSERT INTO parents
            (email,password,name,center_name,phone,created_at)
            VALUES (?,?,?,?,?,?)""",
            (email, hashed, name.strip(), center_name, phone,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit(); conn.close()
        return True, "تم التسجيل بنجاح! يمكنك تسجيل الدخول الآن"
    except Exception as e:
        return False, f"خطأ: {e}"

def login_parent(email, password):
    """تسجيل دخول ولي الأمر"""
    email = email.strip().lower()
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id,password,name,is_active FROM parents WHERE email=?", (email,))
        row = c.fetchone()
        if not row:
            conn.close()
            return False, None, "البريد الإلكتروني غير مسجل"
        pid, hashed, name, active = row
        if not active:
            conn.close()
            return False, None, "الحساب موقوف"
        if not _verify_pw(password, hashed):
            conn.close()
            return False, None, "كلمة المرور غير صحيحة"
        token = secrets.token_urlsafe(32)
        expires = (datetime.now() + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("INSERT INTO sessions (token,parent_id,created_at,expires_at) VALUES (?,?,?,?)",
                  (token, pid, now_str, expires))
        c.execute("UPDATE parents SET last_login=? WHERE id=?", (now_str, pid))
        conn.commit(); conn.close()
        return True, {"token": token, "name": name, "parent_id": pid}, "مرحباً بك!"
    except Exception as e:
        return False, None, f"خطأ: {e}"

def verify_token(token):
    """التحقق من صحة التوكن"""
    if not token: return None
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""SELECT s.parent_id, p.name, p.email, p.center_name
                     FROM sessions s JOIN parents p ON s.parent_id=p.id
                     WHERE s.token=? AND s.expires_at > ?""",
                  (token, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        row = c.fetchone()
        conn.close()
        if row:
            return {"parent_id": row[0], "name": row[1],
                    "email": row[2], "center_name": row[3]}
        return None
    except: return None

def logout_token(token):
    """تسجيل الخروج"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("DELETE FROM sessions WHERE token=?", (token,))
        conn.commit(); conn.close()
    except: pass

def get_children(parent_id):
    """جلب أطفال ولي الأمر"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id,name,age,asd_level,notes,created_at FROM children WHERE parent_id=?",
                  (parent_id,))
        rows = c.fetchall(); conn.close()
        return [{"id":r[0],"name":r[1],"age":r[2],"level":r[3],
                 "notes":r[4],"added":r[5]} for r in rows]
    except: return []

def add_child(parent_id, name, age, level, notes=""):
    """إضافة طفل"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("""INSERT INTO children (parent_id,name,age,asd_level,notes,created_at)
                        VALUES (?,?,?,?,?,?)""",
                     (parent_id, name, age, level, notes,
                      datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit(); conn.close()
        return True
    except: return False

