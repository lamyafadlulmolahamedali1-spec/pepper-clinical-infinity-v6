#!/bin/bash
# تحميل نموذج الصوت العربي Piper
echo "📥 تحميل نموذج ar_JO-kareem-medium..."
mkdir -p ~/pepper_duo/models
cd ~/pepper_duo/models

# تحميل النموذج
wget -q --show-progress \
  "https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx" \
  -O ar_JO-kareem-medium.onnx

wget -q \
  "https://huggingface.co/rhasspy/piper-voices/resolve/main/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx.json" \
  -O ar_JO-kareem-medium.onnx.json

echo "✅ النموذج جاهز: ~/pepper_duo/models/ar_JO-kareem-medium.onnx"

# اختبار الصوت
echo "🔊 اختبار الصوت..."
echo "أهلاً! أنا بيبر روبوت العلاج العربي!" | piper \
  --model ~/pepper_duo/models/ar_JO-kareem-medium.onnx \
  --length_scale 0.85 \
  --output_file /tmp/test_piper.wav && aplay /tmp/test_piper.wav

echo "✅ الصوت يعمل!"
